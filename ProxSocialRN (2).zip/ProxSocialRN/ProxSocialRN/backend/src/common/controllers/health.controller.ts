import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { RedisService } from '../../config/redis.service';

@ApiTags('health')
@Controller('api')
export class HealthController {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private readonly redis: RedisService,
  ) {}

  @Get('health')
  @ApiOperation({ summary: 'Health check — no requiere autenticación' })
  async check() {
    let db = false;
    let redisOk = false;

    try {
      await this.dataSource.query('SELECT 1');
      db = true;
    } catch {}

    try {
      await this.redis.client.ping();
      redisOk = true;
    } catch {}

    return {
      status: db && redisOk ? 'ok' : 'degraded',
      db,
      redis: redisOk,
      uptime: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
    };
  }
}
