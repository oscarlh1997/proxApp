import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

/**
 * Middleware que redirige HTTP → HTTPS en producción.
 * Detecta el protocolo original via x-forwarded-proto (para proxies/load balancers).
 */
@Injectable()
export class HttpsRedirectMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    const proto = req.headers['x-forwarded-proto'] || req.protocol;
    if (proto !== 'https' && process.env.NODE_ENV === 'production') {
      return res.redirect(301, `https://${req.hostname}${req.originalUrl}`);
    }
    next();
  }
}
