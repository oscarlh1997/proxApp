import { IsEmail, IsNotEmpty, IsOptional, IsString, Matches, MaxLength, MinLength } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class RegisterDto {
  @ApiProperty({ example: 'juanito', description: 'Nombre de usuario único (3-30 chars, alfanumérico + guiones)' })
  @IsString()
  @IsNotEmpty({ message: 'El username es obligatorio' })
  @MinLength(3, { message: 'El username debe tener al menos 3 caracteres' })
  @MaxLength(30, { message: 'El username no puede tener más de 30 caracteres' })
  @Matches(/^[a-zA-Z0-9_-]+$/, { message: 'El username solo puede contener letras, números, guiones y guiones bajos' })
  username: string;

  @ApiProperty({ example: 'juanito@email.com' })
  @IsEmail({}, { message: 'Introduce un email válido' })
  @IsNotEmpty({ message: 'El email es obligatorio' })
  @MaxLength(255, { message: 'El email no puede tener más de 255 caracteres' })
  email: string;

  @ApiProperty({ example: 'miPassword123', description: 'Mínimo 6 caracteres' })
  @IsString()
  @IsNotEmpty({ message: 'La contraseña es obligatoria' })
  @MinLength(6, { message: 'La contraseña debe tener al menos 6 caracteres' })
  @MaxLength(100, { message: 'La contraseña no puede tener más de 100 caracteres' })
  password: string;

  @ApiPropertyOptional({ example: 'Juan García', description: 'Nombre para mostrar (usa username si no se proporciona)' })
  @IsOptional()
  @IsString()
  @MaxLength(100, { message: 'El nombre no puede tener más de 100 caracteres' })
  displayName?: string;
}
