import { ConflictException, Inject, Injectable, UnauthorizedException, BadRequestException, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { USER_REPOSITORY, IUserRepository } from '../../user/domain/ports/user-repository.port';
import { RedisService } from '../../../config/redis.service';

/** Datos devueltos al frontend tras autenticación */
export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  user: {
    id: string;
    username: string;
    displayName: string;
    email: string;
    avatarSeed: string;
    bio: string;
    visible: boolean;
  };
}

@Injectable()
export class AuthService {
  private readonly logger = new Logger('AuthService');

  constructor(
    @Inject(USER_REPOSITORY) private readonly userRepo: IUserRepository,
    private readonly jwtService: JwtService,
    private readonly redis: RedisService,
  ) {}

  private generateTokens(userId: string): { accessToken: string; refreshToken: string; jti: string; rtId: string } {
    const jti = uuidv4();
    const rtId = uuidv4();
    const accessToken = this.jwtService.sign(
      { id: userId, sub: userId, jti },
      { expiresIn: '15m' },
    );
    const refreshToken = this.jwtService.sign(
      { id: userId, sub: userId, jti: rtId, type: 'refresh' },
      { expiresIn: '7d' },
    );
    return { accessToken, refreshToken, jti, rtId };
  }

  async register(dto: { username: string; email: string; password: string; displayName?: string }): Promise<AuthResponse> {
    const normalizedEmail = dto.email.trim().toLowerCase();

    const existing = await this.userRepo.findByEmail(normalizedEmail);
    if (existing) throw new ConflictException('Email ya registrado');
    const existingUsername = await this.userRepo.findByUsername(dto.username.trim());
    if (existingUsername) throw new ConflictException('Username ya existe');

    const passwordHash = await bcrypt.hash(dto.password, 12);
    const user = await this.userRepo.create({
      username: dto.username.trim(),
      email: normalizedEmail,
      passwordHash,
      displayName: (dto.displayName || dto.username).trim(),
      avatarSeed: dto.username.toLowerCase().slice(0, 8),
    });

    const { accessToken, refreshToken, rtId } = this.generateTokens(user.id);
    await this.redis.storeRefreshToken(user.id, rtId, 604800); // 7 días

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        email: normalizedEmail,
        avatarSeed: user.avatarSeed,
        bio: user.bio,
        visible: user.visible,
      },
    };
  }

  async login(dto: { email: string; password: string }): Promise<AuthResponse> {
    const normalizedEmail = dto.email.trim().toLowerCase();

    const user = await this.userRepo.findByEmail(normalizedEmail);
    if (!user) throw new UnauthorizedException('Credenciales inválidas');

    const valid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!valid) throw new UnauthorizedException('Credenciales inválidas');

    const { accessToken, refreshToken, rtId } = this.generateTokens(user.id);
    await this.redis.storeRefreshToken(user.id, rtId, 604800);

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        email: user.email || normalizedEmail,
        avatarSeed: user.avatarSeed,
        bio: user.bio,
        visible: user.visible,
      },
    };
  }

  /** Renueva access token usando refresh token */
  async refresh(refreshToken: string): Promise<{ accessToken: string; refreshToken: string }> {
    try {
      const payload = this.jwtService.verify(refreshToken);
      if (payload.type !== 'refresh') throw new Error();

      const userId = await this.redis.getRefreshTokenUser(payload.jti);
      if (!userId || userId !== payload.id) throw new Error();

      // Revocar el refresh token usado (rotation)
      await this.redis.revokeRefreshToken(payload.jti);

      // Generar nuevos tokens
      const { accessToken, refreshToken: newRt, rtId } = this.generateTokens(userId);
      await this.redis.storeRefreshToken(userId, rtId, 604800);

      return { accessToken, refreshToken: newRt };
    } catch {
      throw new UnauthorizedException('Refresh token inválido o expirado');
    }
  }

  /** Invalida los tokens actuales del usuario */
  async logout(accessToken: string, refreshToken?: string): Promise<void> {
    try {
      const payload = this.jwtService.verify(accessToken, { ignoreExpiration: true });
      if (payload.jti) {
        // Blacklist access token por el tiempo restante (max 15 min)
        const ttl = Math.max((payload.exp || 0) - Math.floor(Date.now() / 1000), 0);
        if (ttl > 0) await this.redis.blacklistToken(payload.jti, ttl);
      }
    } catch {}

    if (refreshToken) {
      try {
        const rtPayload = this.jwtService.verify(refreshToken, { ignoreExpiration: true });
        if (rtPayload.jti) await this.redis.revokeRefreshToken(rtPayload.jti);
      } catch {}
    }
  }

  /** Comprueba si un token está en la blacklist */
  async isTokenBlacklisted(jti: string): Promise<boolean> {
    return this.redis.isTokenBlacklisted(jti);
  }

  /** Genera código 6 dígitos y lo almacena 10 minutos */
  async forgotPassword(email: string): Promise<{ message: string; code?: string }> {
    const normalizedEmail = email.trim().toLowerCase();
    const user = await this.userRepo.findByEmail(normalizedEmail);
    // No revelamos si el email existe o no (seguridad)
    if (!user) return { message: 'Si el email está registrado, recibirás un código de recuperación' };

    const code = String(Math.floor(100000 + Math.random() * 900000));
    await this.redis.storeResetCode(normalizedEmail, code, 600); // 10 min

    this.logger.log(`[DEV] Reset code for ${normalizedEmail}: ${code}`);

    return {
      message: 'Si el email está registrado, recibirás un código de recuperación',
      code, // Solo en dev — en producción se enviaría por email
    };
  }

  /** Valida código y establece nueva contraseña */
  async resetPassword(email: string, code: string, newPassword: string): Promise<{ message: string }> {
    const normalizedEmail = email.trim().toLowerCase();
    const storedCode = await this.redis.getResetCode(normalizedEmail);

    if (!storedCode || storedCode !== code) {
      throw new BadRequestException('Código inválido o expirado');
    }

    const user = await this.userRepo.findByEmail(normalizedEmail);
    if (!user) throw new BadRequestException('Usuario no encontrado');

    const passwordHash = await bcrypt.hash(newPassword, 12);
    await this.userRepo.updatePassword(user.id, passwordHash);
    await this.redis.deleteResetCode(normalizedEmail);

    return { message: 'Contraseña actualizada correctamente' };
  }

  /** Obtiene datos completos del usuario autenticado */
  async getMe(userId: string) {
    const user = await this.userRepo.findById(userId);
    if (!user) throw new UnauthorizedException('Usuario no encontrado');
    return {
      id: user.id,
      username: user.username,
      displayName: user.displayName,
      avatarSeed: user.avatarSeed,
      bio: user.bio,
      visible: user.visible,
      interests: user.interests,
      socialLinks: user.socialLinks,
      relationshipStatus: user.relationshipStatus,
    };
  }

  async validateJwtPayload(payload: { id: string; jti?: string }) {
    // Comprobar blacklist
    if (payload.jti) {
      const blacklisted = await this.redis.isTokenBlacklisted(payload.jti);
      if (blacklisted) throw new UnauthorizedException('Token revocado');
    }
    const user = await this.userRepo.findById(payload.id);
    if (!user) throw new UnauthorizedException();
    return { id: user.id, username: user.username };
  }
}
