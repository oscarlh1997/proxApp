import { Body, Controller, Get, Inject, Post, Query, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { CurrentUser } from '../../../../common/decorators/current-user.decorator';
import { ProximityService } from '../../application/proximity.service';
import { USER_REPOSITORY, IUserRepository } from '../../../user/domain/ports/user-repository.port';

@ApiTags('proximity')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('api')
export class ProximityController {
  constructor(
    private readonly proximityService: ProximityService,
    @Inject(USER_REPOSITORY) private readonly userRepo: IUserRepository,
  ) {}

  @Post('location')
  async updateLocation(
    @CurrentUser('id') userId: string,
    @Body() body: { latitude: number; longitude: number },
  ) {
    await this.proximityService.updateLocation(userId, body.latitude, body.longitude);
    return { ok: true };
  }

  @Get('nearby')
  async getNearby(
    @CurrentUser('id') userId: string,
    @Query('radius') radius?: string,
    @Query('lat') lat?: string,
    @Query('lon') lon?: string,
  ) {
    const r = parseFloat(radius || '0.5');
    let latitude = lat ? parseFloat(lat) : undefined;
    let longitude = lon ? parseFloat(lon) : undefined;

    if (latitude && longitude) {
      // Actualizar ubicación y buscar
      await this.proximityService.updateLocation(userId, latitude, longitude);
      return this.proximityService.findNearby(userId, latitude, longitude, r);
    }

    // Buscar la última ubicación guardada del usuario
    const user = await this.userRepo.findById(userId);
    if (user?.latitude && user?.longitude) {
      return this.proximityService.findNearby(userId, user.latitude, user.longitude, r);
    }

    // No tiene ubicación registrada
    return [];
  }
}
