import { Body, Controller, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { SeedService } from './seed.service';

@ApiTags('seed')
@Controller('api')
export class SeedController {
  constructor(private readonly seedService: SeedService) {}

  @Post('seed')
  seed() {
    return this.seedService.seed().then((message) => ({ message }));
  }

  /** Reubicar todos los seed users a distancias fijas desde un centro dado */
  @Post('seed/relocate')
  relocate(@Body() body?: { latitude?: number; longitude?: number }) {
    return this.seedService.relocateUsers(body?.latitude, body?.longitude).then((message: string) => ({ message }));
  }
}
