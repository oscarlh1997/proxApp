import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcryptjs';
import { UserEntity } from '../user/infrastructure/repositories/user.entity';
import { UserInterestEntity } from '../user/infrastructure/repositories/user-interest.entity';
import { UserSocialLinkEntity } from '../user/infrastructure/repositories/user-social-link.entity';
import { PostEntity, PostTagEntity } from '../feed/infrastructure/repositories/feed.entities';
import { RedisService } from '../../config/redis.service';

// Centro de referencia para pruebas (Madrid - Puerta del Sol)
const BASE_LAT = 40.4168;
const BASE_LON = -3.7038;

// Convierte metros a grados aproximados (1° lat ≈ 111320m, 1° lon ≈ 111320m * cos(lat))
function metersToLatOffset(meters: number): number { return meters / 111320; }
function metersToLonOffset(meters: number, lat: number): number { return meters / (111320 * Math.cos(lat * Math.PI / 180)); }

// Cada usuario tiene una distancia fija en metros y un ángulo para distribuirlos alrededor del centro
const SEED_USERS = [
  { username: 'ana', email: 'ana@test.com', name: 'Ana García', bio: 'Diseñadora UX. Amante del café y el ML.', status: 'soltera', distanceM: 30, angleDeg: 0, interests: ['ML', 'Café', 'UI/UX', 'Foto'], socials: [{ platform: 'instagram', url: 'https://instagram.com/ana_garcia', handle: '@ana_garcia' }, { platform: 'linkedin', url: 'https://linkedin.com/in/anagarcia', handle: 'Ana García' }], post: '¿Alguien para café y hablar de ML?' },
  { username: 'luis', email: 'luis@test.com', name: 'Luis Martín', bio: 'Runner y dev cloud. Siempre buscando trail nuevo.', status: 'en_relacion', distanceM: 100, angleDeg: 60, interests: ['Trail', 'Cloud', 'Gaming'], socials: [{ platform: 'twitter', url: 'https://twitter.com/luismartin', handle: '@luismartin' }, { platform: 'strava', url: 'https://strava.com/athletes/luis', handle: 'Luis M.' }], post: 'Busco gente para correr trail este finde.' },
  { username: 'mar', email: 'mar@test.com', name: 'Mar López', bio: 'Freelance iOS/Android. Networking lover.', status: 'soltera', distanceM: 200, angleDeg: 120, interests: ['iOS', 'UI/UX', 'Fintech'], socials: [{ platform: 'github', url: 'https://github.com/marlopez', handle: 'marlopez' }, { platform: 'linkedin', url: 'https://linkedin.com/in/marlopez', handle: 'Mar López' }], post: 'Estoy en el coworking: networking y UI/UX!' },
  { username: 'pablo', email: 'pablo@test.com', name: 'Pablo Ruiz', bio: 'Cloud architect. Meetup organizer.', status: 'casado', distanceM: 350, angleDeg: 180, interests: ['Cloud', 'ML', 'Jazz'], socials: [{ platform: 'twitter', url: 'https://twitter.com/pabloruiz', handle: '@pabloruiz' }], post: '¿Quién va al meetup de Cloud hoy?' },
  { username: 'sara', email: 'sara@test.com', name: 'Sara Vega', bio: 'Fotógrafa y ciclista urbana. Me gusta el jazz.', status: 'es_complicado', distanceM: 500, angleDeg: 240, interests: ['Foto', 'Ciclismo', 'Jazz', 'Café'], socials: [{ platform: 'instagram', url: 'https://instagram.com/saravega', handle: '@saravega' }, { platform: 'flickr', url: 'https://flickr.com/saravega', handle: 'Sara V.' }], post: 'Saliendo a hacer fotos por Malasaña. ¿Alguien se apunta?' },
  { username: 'ivan', email: 'ivan@test.com', name: 'Iván Torres', bio: 'Gamer y dev backend. Java/Kotlin.', status: 'soltero', distanceM: 800, angleDeg: 300, interests: ['Gaming', 'Cloud', 'Fútbol'], socials: [{ platform: 'twitch', url: 'https://twitch.tv/ivantorres', handle: 'ivantorres' }, { platform: 'github', url: 'https://github.com/ivant', handle: 'ivant' }], post: 'Buscando equipo para hackathon de gaming este mes.' },
];

@Injectable()
export class SeedService {
  private logger = new Logger('Seed');

  constructor(
    @InjectRepository(UserEntity) private users: Repository<UserEntity>,
    @InjectRepository(UserInterestEntity) private interests: Repository<UserInterestEntity>,
    @InjectRepository(UserSocialLinkEntity) private socialLinks: Repository<UserSocialLinkEntity>,
    @InjectRepository(PostEntity) private posts: Repository<PostEntity>,
    @InjectRepository(PostTagEntity) private postTags: Repository<PostTagEntity>,
    private readonly redis: RedisService,
  ) {}

  async seed(): Promise<string> {
    const hash = await bcrypt.hash('test123', 10);
    let created = 0;

    for (const u of SEED_USERS) {
      // Skip users that already exist (by email)
      const existing = await this.users.findOne({ where: { email: u.email } });
      if (existing) continue;

      // Calculate position at a fixed distance and angle from the base center
      const angleRad = (u.angleDeg * Math.PI) / 180;
      const lat = BASE_LAT + metersToLatOffset(u.distanceM) * Math.cos(angleRad);
      const lon = BASE_LON + metersToLonOffset(u.distanceM, BASE_LAT) * Math.sin(angleRad);

      const user = this.users.create({
        username: u.username, email: u.email, passwordHash: hash,
        displayName: u.name, bio: u.bio, avatarSeed: u.username,
        relationshipStatus: u.status, latitude: lat, longitude: lon,
        locationUpdatedAt: Date.now(), visible: true,
      });
      const saved = await this.users.save(user);
      created++;

      // PostGIS location
      await this.users.createQueryBuilder()
        .update()
        .set({ location: () => `ST_SetSRID(ST_MakePoint(${lon}, ${lat}), 4326)::geography` })
        .where('id = :id', { id: saved.id })
        .execute();

      // Redis GEO (para que aparezcan en queries de proximidad en tiempo real)
      await this.redis.setUserLocation(saved.id, lat, lon, 86400); // 24h TTL

      // Interests
      await this.interests.save(
        u.interests.map((tag) => this.interests.create({ userId: saved.id, tag })),
      );

      // Social links
      await this.socialLinks.save(
        u.socials.map((s) => this.socialLinks.create({ userId: saved.id, platform: s.platform, url: s.url, handle: s.handle })),
      );

      // Post
      const post = this.posts.create({ authorId: saved.id, text: u.post, createdAt: Date.now() - Math.random() * 6 * 3600000 });
      const savedPost = await this.posts.save(post);
      await this.postTags.save(
        u.interests.slice(0, 2).map((tag) => this.postTags.create({ postId: savedPost.id, tag })),
      );
    }

    if (created === 0) {
      this.logger.log('All seed users already exist');
      return 'All seed users already exist. Users: ana(30m), luis(100m), mar(200m), pablo(350m), sara(500m), ivan(800m). Pass: test123';
    }

    this.logger.log(`Seeded ${created} users with fixed distances from center (${BASE_LAT}, ${BASE_LON})`);
    return `Seeded ${created} users at fixed distances: ana(30m), luis(100m), mar(200m), pablo(350m), sara(500m), ivan(800m). Pass: test123. Centro: ${BASE_LAT}, ${BASE_LON}`;
  }

  /**
   * Reubicar todos los seed users a sus distancias predefinidas desde un centro dado.
   * Útil para resetear posiciones cuando ya existen en la DB.
   */
  async relocateUsers(centerLat?: number, centerLon?: number): Promise<string> {
    const cLat = centerLat || BASE_LAT;
    const cLon = centerLon || BASE_LON;
    let relocated = 0;

    for (const u of SEED_USERS) {
      const existing = await this.users.findOne({ where: { email: u.email } });
      if (!existing) continue;

      const angleRad = (u.angleDeg * Math.PI) / 180;
      const lat = cLat + metersToLatOffset(u.distanceM) * Math.cos(angleRad);
      const lon = cLon + metersToLonOffset(u.distanceM, cLat) * Math.sin(angleRad);

      await this.users.update(existing.id, {
        latitude: lat,
        longitude: lon,
        locationUpdatedAt: Date.now(),
        visible: true,
      });

      // Update PostGIS
      await this.users.createQueryBuilder()
        .update()
        .set({ location: () => `ST_SetSRID(ST_MakePoint(${lon}, ${lat}), 4326)::geography` })
        .where('id = :id', { id: existing.id })
        .execute();

      // Update Redis GEO
      await this.redis.setUserLocation(existing.id, lat, lon, 86400); // 24h TTL

      relocated++;
    }

    this.logger.log(`Relocated ${relocated} seed users around center (${cLat}, ${cLon})`);
    return `Relocated ${relocated} users: ana(30m), luis(100m), mar(200m), pablo(350m), sara(500m), ivan(800m) around center ${cLat}, ${cLon}`;
  }
}
