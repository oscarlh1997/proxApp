import { Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { MoreThan, Repository } from 'typeorm';
import { StoryEntity } from './story.entity';
import { USER_REPOSITORY, IUserRepository } from '../user/domain/ports/user-repository.port';

@Injectable()
export class StoryService {
  constructor(
    @InjectRepository(StoryEntity) private readonly stories: Repository<StoryEntity>,
    @Inject(USER_REPOSITORY) private readonly userRepo: IUserRepository,
  ) {}

  async create(userId: string, text: string, imageBase64?: string) {
    const user = await this.userRepo.findById(userId);
    if (!user) throw new Error('User not found');

    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24h
    const story = this.stories.create({
      authorId: userId,
      authorName: user.displayName,
      authorAvatarSeed: user.avatarSeed,
      text,
      imageBase64: imageBase64 || null,
      expiresAt,
    });

    return this.stories.save(story);
  }

  async getActiveStories() {
    return this.stories.find({
      where: { expiresAt: MoreThan(new Date()) },
      order: { createdAt: 'DESC' },
      take: 50,
    });
  }

  async getStoryById(id: string) {
    return this.stories.findOne({ where: { id } });
  }

  /** Limpia stories expiradas (se puede llamar periódicamente) */
  async cleanup() {
    const result = await this.stories
      .createQueryBuilder()
      .delete()
      .where('expires_at < :now', { now: new Date() })
      .execute();
    return { deleted: result.affected || 0 };
  }
}
