import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { StoryService } from './story.service';

@ApiTags('stories')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('api/stories')
export class StoryController {
  constructor(private readonly storyService: StoryService) {}

  @Post()
  @ApiOperation({ summary: 'Crear una story (24h de vida)' })
  create(
    @CurrentUser('id') userId: string,
    @Body() body: { text: string; imageBase64?: string },
  ) {
    return this.storyService.create(userId, body.text, body.imageBase64);
  }

  @Get()
  @ApiOperation({ summary: 'Obtener stories activas (no expiradas)' })
  getAll() {
    return this.storyService.getActiveStories();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obtener una story por ID' })
  getOne(@Param('id') id: string) {
    return this.storyService.getStoryById(id);
  }
}
