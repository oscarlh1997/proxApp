import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('stories')
export class StoryEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'author_id' })
  authorId: string;

  @Column({ name: 'author_name', length: 100 })
  authorName: string;

  @Column({ name: 'author_avatar_seed', length: 50 })
  authorAvatarSeed: string;

  @Column({ type: 'text' })
  text: string;

  @Column({ name: 'image_base64', type: 'text', nullable: true })
  imageBase64: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  /** Las stories expiran 24h después de crearse */
  @Column({ name: 'expires_at', type: 'timestamptz' })
  expiresAt: Date;
}
