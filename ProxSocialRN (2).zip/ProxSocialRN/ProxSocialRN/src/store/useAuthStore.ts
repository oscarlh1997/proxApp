import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

type AuthUser = {
  id: string;
  username: string;
  displayName: string;
  email: string;
  avatarSeed: string;
};

type AuthState = {
  token: string | null;
  refreshToken: string | null;
  userId: string | null;
  username: string | null;
  user: AuthUser | null;
  /** Número de conexiones pendientes (badge) */
  pendingConnections: number;
  setAuth: (token: string, refreshToken: string, user: AuthUser) => void;
  setTokens: (token: string, refreshToken: string) => void;
  setPendingConnections: (count: number) => void;
  logout: () => void;
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      token: null,
      refreshToken: null,
      userId: null,
      username: null,
      user: null,
      pendingConnections: 0,
      setAuth: (token, refreshToken, user) =>
        set({ token, refreshToken, userId: user.id, username: user.username, user }),
      setTokens: (token, refreshToken) =>
        set({ token, refreshToken }),
      setPendingConnections: (count) =>
        set({ pendingConnections: count }),
      logout: () =>
        set({ token: null, refreshToken: null, userId: null, username: null, user: null, pendingConnections: 0 }),
    }),
    { name: 'prox-auth', storage: createJSONStorage(() => AsyncStorage) },
  ),
);
