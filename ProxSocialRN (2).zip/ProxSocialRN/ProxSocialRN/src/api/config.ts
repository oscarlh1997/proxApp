// ═══════════════════════════════════════════════════════════════════════════════
// Configuración del backend.
// Usa variables de entorno (.env) con el prefijo EXPO_PUBLIC_ (Expo SDK 49+).
// Fallback a IP hardcodeada si no hay .env configurado.
// ═══════════════════════════════════════════════════════════════════════════════
const IP = process.env.EXPO_PUBLIC_API_IP || '192.168.1.130';
const PORT = process.env.EXPO_PUBLIC_API_PORT || '3001';

export const API_BASE = `http://${IP}:${PORT}`;
export const WS_URL = `http://${IP}:${PORT}/chat`;
