import { API_BASE } from './config';
import { useAuthStore } from '../store/useAuthStore';

async function apiFetch(path: string, opts: RequestInit = {}) {
  const { token, refreshToken } = useAuthStore.getState();
  const headers: Record<string, string> = { 'Content-Type': 'application/json', ...((opts.headers as any) || {}) };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  let res = await fetch(`${API_BASE}${path}`, { ...opts, headers });

  // Auto-refresh on 401
  if (res.status === 401 && refreshToken && !path.includes('/auth/refresh')) {
    try {
      const refreshRes = await fetch(`${API_BASE}/api/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken }),
      });
      if (refreshRes.ok) {
        const tokens = await refreshRes.json();
        useAuthStore.getState().setTokens(tokens.accessToken, tokens.refreshToken);
        headers['Authorization'] = `Bearer ${tokens.accessToken}`;
        res = await fetch(`${API_BASE}${path}`, { ...opts, headers });
      } else {
        useAuthStore.getState().logout();
        throw new Error('Sesión expirada, inicia sesión de nuevo');
      }
    } catch {
      useAuthStore.getState().logout();
      throw new Error('Sesión expirada, inicia sesión de nuevo');
    }
  }

  if (res.status === 401) {
    useAuthStore.getState().logout();
    throw new Error('Sesión expirada, inicia sesión de nuevo');
  }

  const data = await res.json();
  if (!res.ok) {
    const msg = Array.isArray(data.message) ? data.message[0] : data.message || 'Error desconocido';
    throw new Error(msg);
  }
  return data;
}

export const api = {
  // Auth
  register: (body: any) => apiFetch('/api/auth/register', { method: 'POST', body: JSON.stringify(body) }),
  login: (body: any) => apiFetch('/api/auth/login', { method: 'POST', body: JSON.stringify(body) }),
  getAuthMe: () => apiFetch('/api/auth/me'),
  refreshToken: (rt: string) => apiFetch('/api/auth/refresh', { method: 'POST', body: JSON.stringify({ refreshToken: rt }) }),
  logout: (rt?: string) => apiFetch('/api/auth/logout', { method: 'POST', body: JSON.stringify({ refreshToken: rt }) }),
  forgotPassword: (email: string) => apiFetch('/api/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email }) }),
  resetPassword: (email: string, code: string, newPassword: string) =>
    apiFetch('/api/auth/reset-password', { method: 'POST', body: JSON.stringify({ email, code, newPassword }) }),

  // Health
  health: () => fetch(`${API_BASE}/api/health`).then(r => r.json()),

  // Profile
  getMe: () => apiFetch('/api/profile/me'),
  updateMe: (body: any) => apiFetch('/api/profile/me', { method: 'PUT', body: JSON.stringify(body) }),
  getUser: (id: string) => apiFetch(`/api/profile/${id}`),

  // Location / Nearby
  updateLocation: (lat: number, lon: number) => apiFetch('/api/location', { method: 'POST', body: JSON.stringify({ latitude: lat, longitude: lon }) }),
  getNearby: (radius = 0.5) => apiFetch(`/api/nearby?radius=${radius}`),

  // Feed
  getFeed: (limit = 20, offset = 0) => apiFetch(`/api/feed?limit=${limit}&offset=${offset}`),
  createPost: (text: string, tags: string[]) => apiFetch('/api/posts', { method: 'POST', body: JSON.stringify({ text, tags }) }),
  toggleLike: (postId: string) => apiFetch(`/api/posts/${postId}/like`, { method: 'POST' }),
  toggleSave: (postId: string) => apiFetch(`/api/posts/${postId}/save`, { method: 'POST' }),

  // Comments
  getComments: (postId: string) => apiFetch(`/api/posts/${postId}/comments`),
  addComment: (postId: string, text: string) => apiFetch(`/api/posts/${postId}/comments`, { method: 'POST', body: JSON.stringify({ text }) }),

  // Messages
  getConversations: () => apiFetch('/api/conversations'),
  createConversation: (targetUserId: string) => apiFetch('/api/conversations', { method: 'POST', body: JSON.stringify({ targetUserId }) }),
  getMessages: (convoId: string) => apiFetch(`/api/conversations/${convoId}/messages`),
  sendMessage: (convoId: string, text: string) => apiFetch(`/api/conversations/${convoId}/messages`, { method: 'POST', body: JSON.stringify({ text }) }),

  // Connections
  connect: (userId: string) => apiFetch(`/api/connect/${userId}`, { method: 'POST' }),
  getConnections: () => apiFetch('/api/connections'),
  acceptConnection: (requesterId: string) => apiFetch(`/api/connections/${requesterId}/accept`, { method: 'PUT' }),
  getPendingConnections: () => apiFetch('/api/connections/pending'),

  // Stories
  getStories: () => apiFetch('/api/stories'),
  createStory: (text: string, imageBase64?: string) => apiFetch('/api/stories', { method: 'POST', body: JSON.stringify({ text, imageBase64 }) }),

  // Seed
  seed: () => apiFetch('/api/seed', { method: 'POST' }),
  relocateSeed: (lat?: number, lon?: number) =>
    apiFetch('/api/seed/relocate', { method: 'POST', body: JSON.stringify({ latitude: lat, longitude: lon }) }),
};
