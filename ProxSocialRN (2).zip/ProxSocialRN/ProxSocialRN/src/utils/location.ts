import * as Location from 'expo-location';
import { Alert, Platform } from 'react-native';

export type Coords = { latitude: number; longitude: number };

// Centro de Madrid (fallback si GPS no disponible)
const FALLBACK: Coords = { latitude: 40.4168, longitude: -3.7038 };

let _lastCoords: Coords | null = null;
let _permissionGranted = false;

/**
 * Solicita permisos de ubicación al usuario.
 * Retorna true si se concedieron.
 */
export async function requestLocationPermission(): Promise<boolean> {
  try {
    const { status } = await Location.requestForegroundPermissionsAsync();
    _permissionGranted = status === 'granted';
    if (!_permissionGranted) {
      Alert.alert(
        'Permisos de ubicación',
        'ProxSocial necesita acceso a tu ubicación para detectar personas cercanas. Puedes activarlo en Ajustes.',
      );
    }
    return _permissionGranted;
  } catch {
    return false;
  }
}

/**
 * Obtiene la ubicación actual del dispositivo.
 * - Usa GPS real si los permisos están concedidos.
 * - Devuelve la última posición conocida si GPS falla.
 * - Devuelve fallback (Madrid) si no hay nada.
 */
export async function getCurrentLocation(): Promise<Coords> {
  // Si aún no hemos pedido permisos, pedirlos
  if (!_permissionGranted) {
    await requestLocationPermission();
  }

  if (_permissionGranted) {
    try {
      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      _lastCoords = {
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      };
      return _lastCoords;
    } catch {
      // GPS falló, intentar última posición conocida
      try {
        const last = await Location.getLastKnownPositionAsync();
        if (last) {
          _lastCoords = {
            latitude: last.coords.latitude,
            longitude: last.coords.longitude,
          };
          return _lastCoords;
        }
      } catch {}
    }
  }

  // Retornar última posición conocida o fallback
  return _lastCoords || FALLBACK;
}

/**
 * Comprueba si tenemos permisos de ubicación activos.
 */
export function hasLocationPermission(): boolean {
  return _permissionGranted;
}

/**
 * Devuelve la última coordenada obtenida sin hacer una nueva petición GPS.
 */
export function getLastKnownCoords(): Coords | null {
  return _lastCoords;
}
