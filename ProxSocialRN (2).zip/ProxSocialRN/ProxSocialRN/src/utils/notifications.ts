import { Platform } from 'react-native';

// expo-notifications es opcional — se importa dinámicamente para no romper
// si no está instalado
let Notifications: any = null;
try {
  Notifications = require('expo-notifications');
} catch {}

/**
 * Solicita permisos de notificación.
 */
export async function requestNotificationPermission(): Promise<boolean> {
  if (!Notifications) return false;
  try {
    const { status } = await Notifications.requestPermissionsAsync();
    return status === 'granted';
  } catch {
    return false;
  }
}

/**
 * Envía una notificación local push.
 */
export async function sendLocalNotification(title: string, body: string, data?: Record<string, any>) {
  if (!Notifications) return;
  try {
    await Notifications.scheduleNotificationAsync({
      content: { title, body, data, sound: true },
      trigger: null, // inmediata
    });
  } catch {}
}

/**
 * Configura el handler de notificaciones.
 */
export function setupNotifications() {
  if (!Notifications) return;
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
    }),
  });
}
