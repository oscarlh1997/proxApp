import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import { API_BASE } from '../api/config';
import AsyncStorage from '@react-native-async-storage/async-storage';

const TASK_NAME = 'PROX_BACKGROUND_LOCATION';

/**
 * Define la tarea que se ejecuta en background.
 * Envía la ubicación al backend cada vez que el OS la entrega.
 */
TaskManager.defineTask(TASK_NAME, async ({ data, error }: any) => {
  if (error) return;
  if (data) {
    const { locations } = data as { locations: Location.LocationObject[] };
    const loc = locations[0];
    if (!loc) return;

    try {
      const raw = await AsyncStorage.getItem('prox-auth');
      if (!raw) return;
      const store = JSON.parse(raw);
      const token = store?.state?.token;
      if (!token) return;

      await fetch(`${API_BASE}/api/location`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ latitude: loc.coords.latitude, longitude: loc.coords.longitude }),
      });
    } catch {}
  }
});

/**
 * Inicia el tracking de ubicación en background.
 * Requiere permisos de ubicación en background.
 */
export async function startBackgroundLocation(): Promise<boolean> {
  try {
    const { status: fgStatus } = await Location.requestForegroundPermissionsAsync();
    if (fgStatus !== 'granted') return false;

    const { status: bgStatus } = await Location.requestBackgroundPermissionsAsync();
    if (bgStatus !== 'granted') return false;

    const isTracking = await Location.hasStartedLocationUpdatesAsync(TASK_NAME);
    if (isTracking) return true;

    await Location.startLocationUpdatesAsync(TASK_NAME, {
      accuracy: Location.Accuracy.Balanced,
      timeInterval: 60000,        // cada 60 segundos
      distanceInterval: 20,       // o cada 20 metros
      deferredUpdatesInterval: 60000,
      showsBackgroundLocationIndicator: true,
      foregroundService: {
        notificationTitle: 'ProxSocial',
        notificationBody: 'Tu ubicación se comparte para detectar personas cercanas',
        notificationColor: '#3B82F6',
      },
    });

    return true;
  } catch {
    return false;
  }
}

export async function stopBackgroundLocation(): Promise<void> {
  try {
    const isTracking = await Location.hasStartedLocationUpdatesAsync(TASK_NAME);
    if (isTracking) await Location.stopLocationUpdatesAsync(TASK_NAME);
  } catch {}
}

export async function isBackgroundLocationRunning(): Promise<boolean> {
  try {
    return await Location.hasStartedLocationUpdatesAsync(TASK_NAME);
  } catch {
    return false;
  }
}
