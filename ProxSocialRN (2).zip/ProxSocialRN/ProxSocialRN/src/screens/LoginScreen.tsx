import React, { useState } from 'react';
import { Alert, Pressable, Text, TextInput, View, ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Colors } from '../theme/colors';
import { api } from '../api/client';
import { useAuthStore } from '../store/useAuthStore';
import { getCurrentLocation, requestLocationPermission } from '../utils/location';

export default function LoginScreen({ navigation }: any) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const setAuth = useAuthStore((s) => s.setAuth);

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!email.trim()) errs.email = 'Introduce tu email';
    if (!password) errs.password = 'Introduce tu contraseña';
    setFieldErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleLogin = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const data = await api.login({ email: email.trim().toLowerCase(), password });
      setAuth(data.accessToken, data.refreshToken, data.user);

      // Registrar ubicación GPS para ser detectable
      try {
        await requestLocationPermission();
        const coords = await getCurrentLocation();
        if (coords) {
          await api.updateLocation(coords.latitude, coords.longitude);
        }
      } catch {}
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Credenciales inválidas');
    } finally { setLoading(false); }
  };

  const handleSeed = async () => {
    try {
      const res = await api.seed();
      try { await api.relocateSeed(); } catch {}
      Alert.alert('OK', res.message || 'Datos de prueba creados.\n\nUsuarios y distancias:\n• ana@test.com → 30m\n• luis@test.com → 100m\n• mar@test.com → 200m\n• pablo@test.com → 350m\n• sara@test.com → 500m\n• ivan@test.com → 800m\n\nContraseña: test123');
    }
    catch (e: any) { Alert.alert('Info', e.message); }
  };

  const fieldStyle = (field: string) => ({
    backgroundColor: Colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: fieldErrors[field] ? '#EF4444' : Colors.border,
    padding: 14,
    color: Colors.text,
    marginBottom: 4,
  });

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24 }} keyboardShouldPersistTaps="handled">
        {/* Logo / Title */}
        <View style={{ alignItems: 'center', marginBottom: 36 }}>
          <View style={{ width: 64, height: 64, borderRadius: 20, backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
            <Text style={{ fontSize: 32 }}>📍</Text>
          </View>
          <Text style={{ fontSize: 30, fontWeight: '900', color: Colors.text }}>ProxSocial</Text>
          <Text style={{ color: Colors.subtext, marginTop: 6, fontSize: 15 }}>
            Descubre quién está a tu alrededor
          </Text>
        </View>

        {/* Email */}
        <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Email</Text>
        <TextInput
          placeholder="tu@email.com"
          placeholderTextColor={Colors.subtext}
          value={email}
          onChangeText={(t) => { setEmail(t); setFieldErrors(prev => ({ ...prev, email: '' })); }}
          autoCapitalize="none"
          keyboardType="email-address"
          autoCorrect={false}
          style={fieldStyle('email')}
        />
        {fieldErrors.email ? <Text style={{ color: '#EF4444', fontSize: 12, marginBottom: 8, marginLeft: 4 }}>{fieldErrors.email}</Text> : <View style={{ height: 12 }} />}

        {/* Password */}
        <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Contraseña</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <TextInput
            placeholder="Tu contraseña"
            placeholderTextColor={Colors.subtext}
            value={password}
            onChangeText={(t) => { setPassword(t); setFieldErrors(prev => ({ ...prev, password: '' })); }}
            secureTextEntry={!showPwd}
            style={[fieldStyle('password'), { flex: 1 }]}
          />
          <Pressable onPress={() => setShowPwd(!showPwd)} style={{ position: 'absolute', right: 12, top: 14 }}>
            <Text style={{ fontSize: 18 }}>{showPwd ? '🙈' : '👁️'}</Text>
          </Pressable>
        </View>
        {fieldErrors.password ? <Text style={{ color: '#EF4444', fontSize: 12, marginBottom: 8, marginLeft: 4 }}>{fieldErrors.password}</Text> : <View style={{ height: 12 }} />}

        {/* Login button */}
        <Pressable onPress={handleLogin} disabled={loading}
          style={{ backgroundColor: Colors.primary, borderRadius: 12, padding: 16, alignItems: 'center', marginTop: 8 }}>
          {loading ? <ActivityIndicator color="white" /> : <Text style={{ color: 'white', fontWeight: '800', fontSize: 16 }}>Entrar</Text>}
        </Pressable>

        {/* Register link */}
        <Pressable onPress={() => navigation.navigate('Register')} style={{ marginTop: 16, alignItems: 'center' }}>
          <Text style={{ color: Colors.primary, fontWeight: '600' }}>¿No tienes cuenta? Regístrate</Text>
        </Pressable>

        {/* Forgot password link */}
        <Pressable onPress={() => navigation.navigate('ForgotPassword')} style={{ marginTop: 12, alignItems: 'center' }}>
          <Text style={{ color: Colors.subtext, fontSize: 13 }}>¿Olvidaste tu contraseña?</Text>
        </Pressable>

        {/* Seed section */}
        <View style={{ marginTop: 32, borderTopWidth: 1, borderTopColor: Colors.border, paddingTop: 20 }}>
          <Pressable onPress={handleSeed} style={{ alignItems: 'center', padding: 12, backgroundColor: '#EEF2FF', borderRadius: 12 }}>
            <Text style={{ color: Colors.subtext, fontSize: 13, fontWeight: '600' }}>🌱 Crear datos de prueba (seed)</Text>
          </Pressable>
          <Text style={{ color: Colors.subtext, fontSize: 10, textAlign: 'center', marginTop: 6 }}>
            Crea 6 usuarios ficticios · Para probar entre 2 móviles, crea tus propias cuentas con "Regístrate"
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
