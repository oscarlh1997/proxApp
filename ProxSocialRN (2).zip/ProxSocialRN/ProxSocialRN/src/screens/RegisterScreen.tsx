import React, { useState } from 'react';
import { Alert, Pressable, Text, TextInput, View, ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Colors } from '../theme/colors';
import { api } from '../api/client';
import { useAuthStore } from '../store/useAuthStore';
import { getCurrentLocation, requestLocationPermission } from '../utils/location';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const USERNAME_RE = /^[a-zA-Z0-9_-]+$/;

export default function RegisterScreen({ navigation }: any) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [showConfirmPwd, setShowConfirmPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const setAuth = useAuthStore((s) => s.setAuth);

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    const u = username.trim();
    if (!u) errs.username = 'Username es obligatorio';
    else if (u.length < 3) errs.username = 'Mínimo 3 caracteres';
    else if (u.length > 30) errs.username = 'Máximo 30 caracteres';
    else if (!USERNAME_RE.test(u)) errs.username = 'Solo letras, números, _ y -';

    const em = email.trim();
    if (!em) errs.email = 'Email es obligatorio';
    else if (!EMAIL_RE.test(em)) errs.email = 'Email no válido';

    if (!password) errs.password = 'Contraseña es obligatoria';
    else if (password.length < 6) errs.password = 'Mínimo 6 caracteres';

    if (!confirmPassword) errs.confirmPassword = 'Confirma la contraseña';
    else if (password !== confirmPassword) errs.confirmPassword = 'Las contraseñas no coinciden';

    setFieldErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleRegister = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const data = await api.register({
        username: username.trim(),
        email: email.trim().toLowerCase(),
        password,
        displayName: (displayName.trim() || username.trim()),
      });
      setAuth(data.accessToken, data.refreshToken, data.user);

      // Registrar ubicación GPS para que el nuevo usuario sea detectable
      try {
        await requestLocationPermission();
        const coords = await getCurrentLocation();
        if (coords) {
          await api.updateLocation(coords.latitude, coords.longitude);
        }
      } catch {}

      // Navegar a onboarding para completar perfil
      navigation.reset({ index: 0, routes: [{ name: 'Onboarding' as never }] });
    } catch (e: any) {
      Alert.alert('Error al registrarse', e.message || 'Inténtalo de nuevo');
    } finally { setLoading(false); }
  };

  const fieldStyle = (field: string) => ({
    backgroundColor: Colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: fieldErrors[field] ? '#EF4444' : Colors.border,
    padding: 14,
    color: Colors.text,
    marginBottom: 4,
  });

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: Colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={{ padding: 24, paddingTop: 40 }} keyboardShouldPersistTaps="handled">
        <Text style={{ fontSize: 26, fontWeight: '900', color: Colors.text, textAlign: 'center', marginBottom: 6 }}>
          Crear cuenta
        </Text>
        <Text style={{ color: Colors.subtext, textAlign: 'center', marginBottom: 28, fontSize: 14 }}>
          Regístrate y descubre quién está cerca
        </Text>

        {/* Username */}
        <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Username *</Text>
        <TextInput
          placeholder="ej: juanito"
          placeholderTextColor={Colors.subtext}
          value={username}
          onChangeText={(t) => { setUsername(t); setFieldErrors(prev => ({ ...prev, username: '' })); }}
          autoCapitalize="none"
          autoCorrect={false}
          style={fieldStyle('username')}
        />
        {fieldErrors.username ? <Text style={{ color: '#EF4444', fontSize: 12, marginBottom: 8, marginLeft: 4 }}>{fieldErrors.username}</Text> : <View style={{ height: 12 }} />}

        {/* Display name */}
        <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Nombre para mostrar</Text>
        <TextInput
          placeholder="ej: Juan García (opcional)"
          placeholderTextColor={Colors.subtext}
          value={displayName}
          onChangeText={setDisplayName}
          style={fieldStyle('displayName')}
        />
        <View style={{ height: 12 }} />

        {/* Email */}
        <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Email *</Text>
        <TextInput
          placeholder="tu@email.com"
          placeholderTextColor={Colors.subtext}
          value={email}
          onChangeText={(t) => { setEmail(t); setFieldErrors(prev => ({ ...prev, email: '' })); }}
          autoCapitalize="none"
          keyboardType="email-address"
          autoCorrect={false}
          style={fieldStyle('email')}
        />
        {fieldErrors.email ? <Text style={{ color: '#EF4444', fontSize: 12, marginBottom: 8, marginLeft: 4 }}>{fieldErrors.email}</Text> : <View style={{ height: 12 }} />}

        {/* Password */}
        <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Contraseña *</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <TextInput
            placeholder="Mínimo 6 caracteres"
            placeholderTextColor={Colors.subtext}
            value={password}
            onChangeText={(t) => { setPassword(t); setFieldErrors(prev => ({ ...prev, password: '' })); }}
            secureTextEntry={!showPwd}
            style={[fieldStyle('password'), { flex: 1 }]}
          />
          <Pressable onPress={() => setShowPwd(!showPwd)} style={{ position: 'absolute', right: 12, top: 14 }}>
            <Text style={{ fontSize: 18 }}>{showPwd ? '🙈' : '👁️'}</Text>
          </Pressable>
        </View>
        {fieldErrors.password ? <Text style={{ color: '#EF4444', fontSize: 12, marginBottom: 8, marginLeft: 4 }}>{fieldErrors.password}</Text> : <View style={{ height: 12 }} />}

        {/* Confirm password */}
        <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Confirmar contraseña *</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <TextInput
            placeholder="Repite la contraseña"
            placeholderTextColor={Colors.subtext}
            value={confirmPassword}
            onChangeText={(t) => { setConfirmPassword(t); setFieldErrors(prev => ({ ...prev, confirmPassword: '' })); }}
            secureTextEntry={!showConfirmPwd}
            style={[fieldStyle('confirmPassword'), { flex: 1 }]}
          />
          <Pressable onPress={() => setShowConfirmPwd(!showConfirmPwd)} style={{ position: 'absolute', right: 12, top: 14 }}>
            <Text style={{ fontSize: 18 }}>{showConfirmPwd ? '🙈' : '👁️'}</Text>
          </Pressable>
        </View>
        {fieldErrors.confirmPassword ? <Text style={{ color: '#EF4444', fontSize: 12, marginBottom: 8, marginLeft: 4 }}>{fieldErrors.confirmPassword}</Text> : <View style={{ height: 12 }} />}

        {/* Password strength hint */}
        {password.length > 0 && (
          <View style={{ flexDirection: 'row', marginBottom: 12, marginTop: 4 }}>
            {[1, 2, 3].map(level => (
              <View key={level} style={{
                flex: 1, height: 4, borderRadius: 2, marginRight: level < 3 ? 4 : 0,
                backgroundColor: password.length >= level * 4 ? (level === 3 ? '#22C55E' : level === 2 ? '#F59E0B' : '#EF4444') : Colors.border,
              }} />
            ))}
          </View>
        )}

        {/* Register button */}
        <Pressable onPress={handleRegister} disabled={loading}
          style={{ backgroundColor: Colors.primary, borderRadius: 12, padding: 16, alignItems: 'center', marginTop: 8 }}>
          {loading ? <ActivityIndicator color="white" /> : <Text style={{ color: 'white', fontWeight: '800', fontSize: 16 }}>Crear cuenta</Text>}
        </Pressable>

        <Pressable onPress={() => navigation.goBack()} style={{ marginTop: 16, alignItems: 'center' }}>
          <Text style={{ color: Colors.primary, fontWeight: '600' }}>Ya tengo cuenta · Iniciar sesión</Text>
        </Pressable>

        <View style={{ height: 40 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
