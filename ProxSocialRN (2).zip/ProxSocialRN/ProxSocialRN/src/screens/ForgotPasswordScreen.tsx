import React, { useState } from 'react';
import { Alert, Pressable, Text, TextInput, View, ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Colors } from '../theme/colors';
import { api } from '../api/client';

type Step = 'email' | 'code' | 'done';

export default function ForgotPasswordScreen({ navigation }: any) {
  const [step, setStep] = useState<Step>('email');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [devCode, setDevCode] = useState('');

  const handleSendCode = async () => {
    if (!email.trim()) return Alert.alert('Error', 'Introduce tu email');
    setLoading(true);
    try {
      const res = await api.forgotPassword(email.trim().toLowerCase());
      if (res.code) setDevCode(res.code); // Solo en dev
      setStep('code');
      Alert.alert('Código enviado', res.code
        ? `[DEV] Tu código es: ${res.code}\n\nEn producción se enviaría por email.`
        : 'Si el email está registrado, recibirás un código.'
      );
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally { setLoading(false); }
  };

  const handleResetPassword = async () => {
    if (!code.trim()) return Alert.alert('Error', 'Introduce el código');
    if (newPassword.length < 6) return Alert.alert('Error', 'La contraseña debe tener al menos 6 caracteres');
    if (newPassword !== confirmPassword) return Alert.alert('Error', 'Las contraseñas no coinciden');
    setLoading(true);
    try {
      await api.resetPassword(email.trim().toLowerCase(), code.trim(), newPassword);
      setStep('done');
      Alert.alert('¡Listo!', 'Contraseña actualizada. Ya puedes iniciar sesión.', [
        { text: 'Ir a Login', onPress: () => navigation.goBack() },
      ]);
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally { setLoading(false); }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: Colors.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24 }} keyboardShouldPersistTaps="handled">
        <Text style={{ fontSize: 24, fontWeight: '900', color: Colors.text, textAlign: 'center', marginBottom: 8 }}>
          {step === 'email' ? '🔑 Recuperar contraseña' : step === 'code' ? '🔢 Introduce el código' : '✅ ¡Listo!'}
        </Text>
        <Text style={{ color: Colors.subtext, textAlign: 'center', marginBottom: 28 }}>
          {step === 'email'
            ? 'Introduce tu email y te enviaremos un código de 6 dígitos'
            : step === 'code'
            ? 'Introduce el código y tu nueva contraseña'
            : 'Tu contraseña ha sido actualizada'}
        </Text>

        {step === 'email' && (
          <>
            <TextInput
              placeholder="tu@email.com"
              placeholderTextColor={Colors.subtext}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              style={{ backgroundColor: Colors.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.border, padding: 14, color: Colors.text, marginBottom: 16 }}
            />
            <Pressable onPress={handleSendCode} disabled={loading}
              style={{ backgroundColor: Colors.primary, borderRadius: 12, padding: 16, alignItems: 'center' }}>
              {loading ? <ActivityIndicator color="white" /> : <Text style={{ color: 'white', fontWeight: '800', fontSize: 16 }}>Enviar código</Text>}
            </Pressable>
          </>
        )}

        {step === 'code' && (
          <>
            {devCode ? (
              <View style={{ backgroundColor: '#FEF3C7', borderRadius: 8, padding: 10, marginBottom: 16 }}>
                <Text style={{ color: '#92400E', textAlign: 'center', fontSize: 12 }}>
                  [DEV] Código: <Text style={{ fontWeight: '900', fontSize: 18 }}>{devCode}</Text>
                </Text>
              </View>
            ) : null}

            <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Código de verificación</Text>
            <TextInput
              placeholder="123456"
              placeholderTextColor={Colors.subtext}
              value={code}
              onChangeText={setCode}
              keyboardType="number-pad"
              maxLength={6}
              style={{ backgroundColor: Colors.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.border, padding: 14, color: Colors.text, marginBottom: 16, fontSize: 24, textAlign: 'center', letterSpacing: 8 }}
            />
            <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Nueva contraseña</Text>
            <TextInput
              placeholder="Mínimo 6 caracteres"
              placeholderTextColor={Colors.subtext}
              value={newPassword}
              onChangeText={setNewPassword}
              secureTextEntry
              style={{ backgroundColor: Colors.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.border, padding: 14, color: Colors.text, marginBottom: 12 }}
            />
            <Text style={{ fontWeight: '700', color: Colors.text, marginBottom: 6, fontSize: 13 }}>Confirmar contraseña</Text>
            <TextInput
              placeholder="Repite la contraseña"
              placeholderTextColor={Colors.subtext}
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry
              style={{ backgroundColor: Colors.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.border, padding: 14, color: Colors.text, marginBottom: 20 }}
            />
            <Pressable onPress={handleResetPassword} disabled={loading}
              style={{ backgroundColor: Colors.primary, borderRadius: 12, padding: 16, alignItems: 'center' }}>
              {loading ? <ActivityIndicator color="white" /> : <Text style={{ color: 'white', fontWeight: '800', fontSize: 16 }}>Cambiar contraseña</Text>}
            </Pressable>
          </>
        )}

        <Pressable onPress={() => navigation.goBack()} style={{ marginTop: 20, alignItems: 'center' }}>
          <Text style={{ color: Colors.primary, fontWeight: '600' }}>Volver al login</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
