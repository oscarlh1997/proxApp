import React, { useCallback, useEffect, useState } from 'react';
import { RefreshControl, ScrollView, Switch, Text, TextInput, View, Pressable } from 'react-native';
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, FadeIn } from 'react-native-reanimated';
import { Colors } from '../theme/colors';
import { RadarSvg } from '../components/RadarSvg';
import { NearbyUserCard } from '../components/NearbyUserCard';
import { api } from '../api/client';
import { NearbyUser } from '../types/models';
import { hashToAngleDeg } from '../utils/hash';
import { useNavigation } from '@react-navigation/native';
import { getCurrentLocation, requestLocationPermission, Coords } from '../utils/location';
import { useAuthStore } from '../store/useAuthStore';
import { startBackgroundLocation, stopBackgroundLocation } from '../utils/backgroundLocation';
import { sendLocalNotification } from '../utils/notifications';

type LocationMode = 'gps' | 'manual';

export default function RadarScreen() {
  const nav = useNavigation<any>();
  const user = useAuthStore((s) => s.user);
  const [nearby, setNearby] = useState<NearbyUser[]>([]);
  const [visible, setVisible] = useState(true);
  const [scanning, setScanning] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [radiusKm, setRadiusKm] = useState(0.5);
  const [locationMode, setLocationMode] = useState<LocationMode>('gps');
  const [manualLat, setManualLat] = useState('40.4168');
  const [manualLon, setManualLon] = useState('-3.7038');
  const [currentCoords, setCurrentCoords] = useState<Coords | null>(null);
  const [gpsError, setGpsError] = useState(false);
  const [bgLocationOn, setBgLocationOn] = useState(false);
  const [knownIds, setKnownIds] = useState<Set<string>>(new Set());

  // My interests for shared-interests highlighting
  const [myInterests, setMyInterests] = useState<string[]>([]);

  // Pulse animation for the "scanning" indicator
  const pulse = useSharedValue(1);
  useEffect(() => {
    pulse.value = withRepeat(withTiming(1.3, { duration: 1000 }), -1, true);
  }, []);
  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
    opacity: 2 - pulse.value, // 1 → 0.7
  }));

  // Load profile interests once
  useEffect(() => {
    (async () => {
      try {
        const me = await api.getMe();
        setMyInterests(me.interests || []);
      } catch {}
    })();
  }, []);

  // Pedir permisos al montar
  useEffect(() => {
    requestLocationPermission();
  }, []);

  const load = useCallback(async () => {
    try {
      let coords: Coords;

      if (locationMode === 'gps') {
        try {
          coords = await getCurrentLocation();
          setGpsError(false);
        } catch {
          setGpsError(true);
          coords = { latitude: parseFloat(manualLat) || 40.4168, longitude: parseFloat(manualLon) || -3.7038 };
        }
      } else {
        coords = { latitude: parseFloat(manualLat) || 40.4168, longitude: parseFloat(manualLon) || -3.7038 };
      }

      setCurrentCoords(coords);

      // Enviar ubicación al backend
      try {
        await api.updateLocation(coords.latitude, coords.longitude);
      } catch {}

      if (scanning) {
        const data = await api.getNearby(radiusKm);
        const enriched: NearbyUser[] = data.map((u: any) => ({
          ...u,
          angleDeg: hashToAngleDeg(u.id || u.username || ''),
          bucket: u.distanceM <= 50 ? 'NEAR' : u.distanceM <= 150 ? 'MID' : 'FAR',
          tags: u.interests,
          lastSeenAt: Date.now(),
        }));

        // Detect newly appeared users → push local notification
        const newIds = new Set(enriched.map(u => u.id || u.rpi || '').filter(Boolean));
        const appeared = enriched.filter(u => {
          const uid = u.id || u.rpi || '';
          return uid && !knownIds.has(uid);
        });
        if (appeared.length > 0 && knownIds.size > 0) {
          sendLocalNotification(
            '📡 Nueva persona cerca',
            `${appeared[0].displayName}${appeared.length > 1 ? ` y ${appeared.length - 1} más` : ''} está cerca de ti`,
          );
        }
        setKnownIds(newIds);
        setNearby(enriched);
      }
    } catch {}
  }, [scanning, radiusKm, locationMode, manualLat, manualLon]);

  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, [load]);
  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const handleVisibleChange = async (v: boolean) => {
    setVisible(v);
    try { await api.updateMe({ visible: v }); } catch {}
  };

  const handleBgLocation = async (v: boolean) => {
    setBgLocationOn(v);
    if (v) {
      await startBackgroundLocation();
    } else {
      await stopBackgroundLocation();
    }
  };

  const radiusLabel = radiusKm >= 1 ? `${radiusKm.toFixed(1)} km` : `${Math.round(radiusKm * 1000)} m`;

  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.bg }} contentContainerStyle={{ padding: 12 }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>

      {/* Radar card */}
      <View style={{ backgroundColor: Colors.card, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 12 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: Colors.text }}>Radar</Text>
            {scanning && (
              <Animated.View style={[{ width: 10, height: 10, borderRadius: 5, backgroundColor: Colors.near, marginLeft: 8 }, pulseStyle]} />
            )}
          </View>
          {/* Invisible mode quick-toggle */}
          <Pressable
            onPress={() => handleVisibleChange(!visible)}
            style={{
              flexDirection: 'row', alignItems: 'center',
              backgroundColor: visible ? '#ECFDF5' : '#FEF3C7',
              paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999,
            }}
          >
            <Text style={{ fontSize: 14, marginRight: 4 }}>{visible ? '👁️' : '🫥'}</Text>
            <Text style={{ fontSize: 12, fontWeight: '700', color: visible ? '#065F46' : '#92400E' }}>
              {visible ? 'Visible' : 'Invisible'}
            </Text>
          </Pressable>
        </View>
        <Text style={{ color: Colors.subtext, marginTop: 6 }}>
          Descubre personas cerca de ti usando tu GPS real.
        </Text>

        {/* Coordenadas actuales */}
        {currentCoords && (
          <View style={{ backgroundColor: locationMode === 'gps' ? '#ECFDF5' : '#EEF2FF', borderRadius: 8, padding: 8, marginTop: 8 }}>
            <Text style={{ color: locationMode === 'gps' ? '#065F46' : '#3730A3', fontSize: 11, textAlign: 'center' }}>
              {locationMode === 'gps' ? '📡 GPS' : '📍 Manual'}: {currentCoords.latitude.toFixed(6)}, {currentCoords.longitude.toFixed(6)}
            </Text>
          </View>
        )}

        {gpsError && locationMode === 'gps' && (
          <View style={{ backgroundColor: '#FEF3C7', borderRadius: 8, padding: 8, marginTop: 6 }}>
            <Text style={{ color: '#92400E', fontSize: 11, textAlign: 'center' }}>
              ⚠️ GPS no disponible, usando última posición conocida
            </Text>
          </View>
        )}

        <View style={{ marginTop: 12 }}>
          <RadarSvg users={nearby} size={320} />
        </View>

        {/* Radio de búsqueda */}
        <View style={{ marginTop: 14, backgroundColor: '#F1F5F9', borderRadius: 12, padding: 12 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <Text style={{ color: Colors.text, fontWeight: '700' }}>Radio de búsqueda</Text>
            <Text style={{ color: Colors.primary, fontWeight: '800', fontSize: 16 }}>{radiusLabel}</Text>
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {[
              { label: '50m', value: 0.05 },
              { label: '100m', value: 0.1 },
              { label: '200m', value: 0.2 },
              { label: '350m', value: 0.35 },
              { label: '500m', value: 0.5 },
              { label: '800m', value: 0.8 },
              { label: '1 km', value: 1.0 },
              { label: '2 km', value: 2.0 },
            ].map((opt) => {
              const active = Math.abs(radiusKm - opt.value) < 0.01;
              return (
                <Pressable key={opt.value} onPress={() => setRadiusKm(opt.value)}
                  style={{
                    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999,
                    backgroundColor: active ? Colors.primary : Colors.card,
                    borderWidth: 1, borderColor: active ? Colors.primary : Colors.border,
                  }}>
                  <Text style={{ color: active ? 'white' : Colors.text, fontWeight: '700', fontSize: 13 }}>
                    {opt.label}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* Controles */}
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 14 }}>
          <Text style={{ color: Colors.text, fontWeight: '700', flex: 1 }}>Visible para otros</Text>
          <Switch value={visible} onValueChange={handleVisibleChange} />
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8 }}>
          <Text style={{ color: Colors.text, fontWeight: '700', flex: 1 }}>Escanear cercanos</Text>
          <Switch value={scanning} onValueChange={setScanning} />
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8 }}>
          <Text style={{ color: Colors.text, fontWeight: '700', flex: 1 }}>Ubicación en segundo plano</Text>
          <Switch value={bgLocationOn} onValueChange={handleBgLocation} />
        </View>
      </View>

      {/* Modo de ubicación */}
      <View style={{ backgroundColor: Colors.card, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 12, marginTop: 14 }}>
        <Text style={{ fontWeight: '800', color: Colors.text, marginBottom: 10 }}>📍 Fuente de ubicación</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Pressable onPress={() => setLocationMode('gps')}
            style={{
              flex: 1, padding: 12, borderRadius: 12, alignItems: 'center',
              backgroundColor: locationMode === 'gps' ? Colors.primary : '#F1F5F9',
              borderWidth: 1, borderColor: locationMode === 'gps' ? Colors.primary : Colors.border,
            }}>
            <Text style={{ fontSize: 20 }}>📡</Text>
            <Text style={{ color: locationMode === 'gps' ? 'white' : Colors.text, fontWeight: '700', fontSize: 13, marginTop: 4 }}>
              GPS Real
            </Text>
            <Text style={{ color: locationMode === 'gps' ? 'rgba(255,255,255,0.7)' : Colors.subtext, fontSize: 10, marginTop: 2, textAlign: 'center' }}>
              Usa el GPS del dispositivo
            </Text>
          </Pressable>
          <Pressable onPress={() => setLocationMode('manual')}
            style={{
              flex: 1, padding: 12, borderRadius: 12, alignItems: 'center',
              backgroundColor: locationMode === 'manual' ? Colors.primary : '#F1F5F9',
              borderWidth: 1, borderColor: locationMode === 'manual' ? Colors.primary : Colors.border,
            }}>
            <Text style={{ fontSize: 20 }}>✏️</Text>
            <Text style={{ color: locationMode === 'manual' ? 'white' : Colors.text, fontWeight: '700', fontSize: 13, marginTop: 4 }}>
              Manual
            </Text>
            <Text style={{ color: locationMode === 'manual' ? 'rgba(255,255,255,0.7)' : Colors.subtext, fontSize: 10, marginTop: 2, textAlign: 'center' }}>
              Introduce coordenadas
            </Text>
          </Pressable>
        </View>

        {locationMode === 'manual' && (
          <View style={{ marginTop: 12 }}>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: Colors.subtext, fontSize: 11, marginBottom: 4 }}>Latitud</Text>
                <TextInput value={manualLat} onChangeText={setManualLat} keyboardType="numeric"
                  style={{ backgroundColor: '#F6F7FB', borderRadius: 8, borderWidth: 1, borderColor: Colors.border, padding: 10, color: Colors.text, fontSize: 13 }} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: Colors.subtext, fontSize: 11, marginBottom: 4 }}>Longitud</Text>
                <TextInput value={manualLon} onChangeText={setManualLon} keyboardType="numeric"
                  style={{ backgroundColor: '#F6F7FB', borderRadius: 8, borderWidth: 1, borderColor: Colors.border, padding: 10, color: Colors.text, fontSize: 13 }} />
              </View>
            </View>
            <Pressable onPress={() => { setManualLat('40.4168'); setManualLon('-3.7038'); }}
              style={{ marginTop: 8, alignItems: 'center' }}>
              <Text style={{ color: Colors.primary, fontSize: 12 }}>Resetear al centro de pruebas (Madrid)</Text>
            </Pressable>
          </View>
        )}
      </View>

      {/* Lista de personas */}
      <Text style={{ fontSize: 18, fontWeight: '800', color: Colors.text, marginTop: 14 }}>
        Personas detectadas ({nearby.length})
      </Text>
      <View style={{ marginTop: 10 }}>
        {nearby.length === 0 ? (
          <Text style={{ color: Colors.subtext }}>
            No hay personas en rango ({radiusLabel}). Aumenta el radio o tira hacia abajo para refrescar.
          </Text>
        ) : (
          nearby.map((u, i) => (
            <Animated.View key={u.id || u.rpi} entering={FadeIn.delay(i * 80).duration(400)}>
              <NearbyUserCard user={u} myInterests={myInterests}
                onConnect={() => nav.navigate('UserDetail', { userId: u.id, nearbyUser: u })} />
            </Animated.View>
          ))
        )}
      </View>
    </ScrollView>
  );
}
