import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Colors } from '../theme/colors';
import { api } from '../api/client';
import { TAGS } from '../mock/mockTags';

export default function OnboardingScreen() {
  const nav = useNavigation<any>();
  const [step, setStep] = useState(0);
  const [bio, setBio] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  const toggleTag = (t: string) => {
    setSelectedTags(prev => prev.includes(t) ? prev.filter(x => x !== t) : [...prev, t]);
  };

  const save = async () => {
    setSaving(true);
    try {
      await api.updateMe({ bio, interests: selectedTags });
      nav.reset({ index: 0, routes: [{ name: 'Tabs' }] });
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally { setSaving(false); }
  };

  const steps = [
    // Step 0: Bio
    <View key="bio">
      <Text style={{ fontSize: 22, fontWeight: '900', color: Colors.text, textAlign: 'center', marginBottom: 8 }}>
        👋 ¡Bienvenido/a!
      </Text>
      <Text style={{ color: Colors.subtext, textAlign: 'center', marginBottom: 24 }}>
        Cuéntale al mundo un poco sobre ti
      </Text>
      <TextInput
        placeholder="Ej: Me gusta el senderismo, la música y viajar..."
        placeholderTextColor={Colors.subtext}
        value={bio}
        onChangeText={setBio}
        multiline
        numberOfLines={4}
        style={{ backgroundColor: Colors.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.border, padding: 14, color: Colors.text, minHeight: 100, textAlignVertical: 'top', marginBottom: 20 }}
      />
      <Pressable onPress={() => setStep(1)}
        style={{ backgroundColor: Colors.primary, borderRadius: 12, padding: 16, alignItems: 'center' }}>
        <Text style={{ color: 'white', fontWeight: '800', fontSize: 16 }}>Siguiente</Text>
      </Pressable>
    </View>,

    // Step 1: Interests
    <View key="interests">
      <Text style={{ fontSize: 22, fontWeight: '900', color: Colors.text, textAlign: 'center', marginBottom: 8 }}>
        🎯 ¿Qué te interesa?
      </Text>
      <Text style={{ color: Colors.subtext, textAlign: 'center', marginBottom: 20 }}>
        Selecciona tus intereses para encontrar personas afines ({selectedTags.length} seleccionados)
      </Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 20 }}>
        {TAGS.map(t => (
          <Pressable key={t} onPress={() => toggleTag(t)}
            style={{
              paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, marginRight: 8, marginBottom: 8,
              backgroundColor: selectedTags.includes(t) ? Colors.primary : Colors.card,
              borderWidth: 1, borderColor: selectedTags.includes(t) ? Colors.primary : Colors.border,
            }}>
            <Text style={{ color: selectedTags.includes(t) ? 'white' : Colors.text, fontWeight: '600', fontSize: 13 }}>
              #{t}
            </Text>
          </Pressable>
        ))}
      </View>
      <Pressable onPress={save} disabled={saving}
        style={{ backgroundColor: Colors.primary, borderRadius: 12, padding: 16, alignItems: 'center' }}>
        {saving ? <ActivityIndicator color="white" /> : <Text style={{ color: 'white', fontWeight: '800', fontSize: 16 }}>¡Empezar a explorar!</Text>}
      </Pressable>
    </View>,
  ];

  return (
    <ScrollView style={{ flex: 1, backgroundColor: Colors.bg }} contentContainerStyle={{ padding: 24, paddingTop: 60 }}>
      {/* Progress */}
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 32 }}>
        {[0, 1].map(i => (
          <View key={i} style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: i <= step ? Colors.primary : Colors.border }} />
        ))}
      </View>

      {steps[step]}

      {step > 0 && (
        <Pressable onPress={() => setStep(s => s - 1)} style={{ marginTop: 16, alignItems: 'center' }}>
          <Text style={{ color: Colors.primary, fontWeight: '600' }}>← Atrás</Text>
        </Pressable>
      )}

      <Pressable onPress={() => nav.reset({ index: 0, routes: [{ name: 'Tabs' }] })}
        style={{ marginTop: 12, alignItems: 'center' }}>
        <Text style={{ color: Colors.subtext, fontSize: 13 }}>Saltar por ahora</Text>
      </Pressable>
    </ScrollView>
  );
}
