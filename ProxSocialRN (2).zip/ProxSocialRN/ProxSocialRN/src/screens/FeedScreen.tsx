import React, { useCallback, useEffect, useState } from 'react';
import { Alert, FlatList, Modal, Pressable, RefreshControl, Text, TextInput, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { PostCard } from '../components/PostCard';
import { StoriesBar } from '../components/StoriesBar';
import { Colors } from '../theme/colors';
import { api } from '../api/client';
import { Post, Story } from '../types/models';
import { NearbyUserCard } from '../components/NearbyUserCard';
import { TagChip } from '../components/TagChip';
import { getCurrentLocation } from '../utils/location';

export default function FeedScreen() {
  const nav = useNavigation<any>();
  const [posts, setPosts] = useState<Post[]>([]);
  const [nearby, setNearby] = useState<any[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [myInterests, setMyInterests] = useState<string[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [newPostText, setNewPostText] = useState('');
  const [showCompose, setShowCompose] = useState(false);
  const [showStoryModal, setShowStoryModal] = useState(false);
  const [storyText, setStoryText] = useState('');

  const load = useCallback(async () => {
    try {
      // Obtener ubicación GPS real del dispositivo
      const coords = await getCurrentLocation();
      try { await api.updateLocation(coords.latitude, coords.longitude); } catch {}
      const [feedData, nearbyData, storiesData, meData] = await Promise.all([
        api.getFeed(),
        api.getNearby(1.0),
        api.getStories().catch(() => []),
        api.getMe().catch(() => null),
      ]);
      setPosts(feedData);
      setNearby(nearbyData);
      if (meData) setMyInterests(meData.interests || []);

      // Map backend stories to Story type
      const mapped: Story[] = (storiesData || []).map((s: any) => ({
        id: s.id,
        userName: s.authorName || 'Anon',
        avatarSeed: s.authorAvatarSeed || s.authorName || '',
        seen: false,
        text: s.text,
      }));
      setStories(mapped);
    } catch {}
  }, []);

  useEffect(() => { load(); }, [load]);

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const createPost = async () => {
    if (!newPostText.trim()) return;
    try {
      await api.createPost(newPostText.trim(), []);
      setNewPostText('');
      setShowCompose(false);
      load();
    } catch (e: any) { Alert.alert('Error', e.message); }
  };

  const createStory = async () => {
    if (!storyText.trim()) return;
    try {
      await api.createStory(storyText.trim());
      setStoryText('');
      setShowStoryModal(false);
      load();
    } catch (e: any) { Alert.alert('Error', e.message); }
  };

  const toggleLike = async (postId: string) => {
    try {
      const res = await api.toggleLike(postId);
      setPosts(prev => prev.map(p => p.id === postId ? { ...p, liked: res.liked, likeCount: res.likeCount } : p));
    } catch {}
  };

  const toggleSave = async (postId: string) => {
    try {
      const res = await api.toggleSave(postId);
      setPosts(prev => prev.map(p => p.id === postId ? { ...p, saved: res.saved } : p));
    } catch {}
  };

  const header = () => (
    <View>
      {/* Stories bar */}
      {stories.length > 0 && (
        <StoriesBar stories={stories} onPressStory={(id) => {
          const story = stories.find(s => s.id === id);
          if (story) Alert.alert(story.userName, (story as any).text || 'Historia');
        }} />
      )}

      {/* Create story button */}
      <Pressable onPress={() => setShowStoryModal(true)}
        style={{
          flexDirection: 'row', alignItems: 'center',
          backgroundColor: Colors.card, borderRadius: 12, borderWidth: 1, borderColor: Colors.border,
          padding: 10, marginBottom: 12,
        }}>
        <Text style={{ fontSize: 20, marginRight: 8 }}>📸</Text>
        <Text style={{ color: Colors.subtext, flex: 1 }}>Crear historia (24h)</Text>
        <Text style={{ color: Colors.primary, fontWeight: '700', fontSize: 13 }}>Publicar</Text>
      </Pressable>

      {/* Nearby preview */}
      {nearby.length > 0 && (
        <View style={{ marginBottom: 14 }}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: Colors.text }}>Cerca de ti</Text>
          <View style={{ marginTop: 8 }}>
            {nearby.slice(0, 3).map((u: any) => (
              <NearbyUserCard key={u.id} user={u} myInterests={myInterests}
                onConnect={() => nav.navigate('UserDetail', { userId: u.id, nearbyUser: u })} />
            ))}
          </View>
        </View>
      )}

      {/* Compose */}
      {showCompose ? (
        <View style={{ backgroundColor: Colors.card, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 12, marginBottom: 14 }}>
          <TextInput value={newPostText} onChangeText={setNewPostText} placeholder="¿Qué quieres compartir?"
            placeholderTextColor={Colors.subtext} multiline
            style={{ color: Colors.text, minHeight: 60, textAlignVertical: 'top' }} />
          <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginTop: 8 }}>
            <Pressable onPress={() => setShowCompose(false)} style={{ paddingHorizontal: 14, paddingVertical: 8, marginRight: 8 }}>
              <Text style={{ color: Colors.subtext }}>Cancelar</Text>
            </Pressable>
            <Pressable onPress={createPost}
              style={{ backgroundColor: Colors.primary, paddingHorizontal: 18, paddingVertical: 8, borderRadius: 999 }}>
              <Text style={{ color: 'white', fontWeight: '700' }}>Publicar</Text>
            </Pressable>
          </View>
        </View>
      ) : (
        <Pressable onPress={() => setShowCompose(true)}
          style={{ backgroundColor: Colors.card, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 14, marginBottom: 14 }}>
          <Text style={{ color: Colors.subtext }}>¿Qué quieres compartir?</Text>
        </Pressable>
      )}

      <Text style={{ fontSize: 18, fontWeight: '800', color: Colors.text, marginBottom: 10 }}>Feed</Text>
    </View>
  );

  return (
    <>
      <FlatList
        style={{ flex: 1, backgroundColor: Colors.bg }}
        contentContainerStyle={{ padding: 12 }}
        data={posts}
        keyExtractor={p => p.id}
        ListHeaderComponent={header}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        renderItem={({ item }) => (
          <PostCard post={item}
            onOpen={() => nav.navigate('PostDetail', { postId: item.id })}
            onLike={() => toggleLike(item.id)}
            onSave={() => toggleSave(item.id)} />
        )}
        ListEmptyComponent={<Text style={{ color: Colors.subtext, textAlign: 'center', marginTop: 20 }}>Sin publicaciones aún. ¡Sé el primero!</Text>}
      />

      {/* Story creation modal */}
      <Modal visible={showStoryModal} transparent animationType="slide">
        <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.4)' }}>
          <View style={{ backgroundColor: Colors.card, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: Colors.text, marginBottom: 12 }}>Nueva historia</Text>
            <TextInput
              value={storyText}
              onChangeText={setStoryText}
              placeholder="Escribe algo... (desaparece en 24h)"
              placeholderTextColor={Colors.subtext}
              multiline
              style={{
                color: Colors.text, backgroundColor: Colors.bg, borderRadius: 12,
                borderWidth: 1, borderColor: Colors.border, padding: 14,
                minHeight: 80, textAlignVertical: 'top',
              }}
            />
            <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginTop: 14 }}>
              <Pressable onPress={() => { setShowStoryModal(false); setStoryText(''); }}
                style={{ paddingHorizontal: 16, paddingVertical: 10, marginRight: 8 }}>
                <Text style={{ color: Colors.subtext, fontWeight: '600' }}>Cancelar</Text>
              </Pressable>
              <Pressable onPress={createStory}
                style={{ backgroundColor: Colors.primary, paddingHorizontal: 20, paddingVertical: 10, borderRadius: 999 }}>
                <Text style={{ color: 'white', fontWeight: '700' }}>Publicar</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}
