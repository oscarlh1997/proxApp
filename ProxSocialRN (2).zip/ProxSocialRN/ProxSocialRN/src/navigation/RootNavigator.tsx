import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import TabsNavigator from './TabsNavigator';
import PostDetailScreen from '../screens/PostDetailScreen';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen';
import OnboardingScreen from '../screens/OnboardingScreen';
import UserDetailScreen from '../screens/UserDetailScreen';
import ChatScreen from '../screens/ChatScreen';
import EditProfileScreen from '../screens/EditProfileScreen';
import { useAuthStore } from '../store/useAuthStore';
import { NearbyUser } from '../types/models';
import { api } from '../api/client';
import { Colors } from '../theme/colors';

export type RootStackParamList = {
  Login: undefined;
  Register: undefined;
  ForgotPassword: undefined;
  Onboarding: undefined;
  Tabs: undefined;
  PostDetail: { postId: string };
  UserDetail: { userId?: string; nearbyUser?: NearbyUser };
  Chat: { conversationId: string; otherName: string };
  EditProfile: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

/** Splash: rehidrata el store persistido y valida el token con el backend */
function SplashView() {
  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator size="large" color={Colors.primary} />
    </View>
  );
}

export default function RootNavigator() {
  const token = useAuthStore((s) => s.token);
  const logout = useAuthStore((s) => s.logout);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    (async () => {
      if (token) {
        try {
          await api.getAuthMe();
        } catch {
          logout();
        }
      }
      setChecking(false);
    })();
  }, []); // Solo al montar

  if (checking) return <SplashView />;

  return (
    <Stack.Navigator>
      {!token ? (
        <>
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Register" component={RegisterScreen} options={{ title: 'Registro', headerShown: false }} />
          <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} options={{ title: 'Recuperar contraseña' }} />
        </>
      ) : (
        <>
          <Stack.Screen name="Tabs" component={TabsNavigator} options={{ headerShown: false }} />
          <Stack.Screen name="Onboarding" component={OnboardingScreen} options={{ title: 'Completa tu perfil', headerShown: false }} />
          <Stack.Screen name="PostDetail" component={PostDetailScreen} options={{ title: 'Comentarios' }} />
          <Stack.Screen name="UserDetail" component={UserDetailScreen} options={{ title: 'Perfil' }} />
          <Stack.Screen name="Chat" component={ChatScreen}
            options={({ route }: any) => ({ title: route.params?.otherName || 'Chat' })} />
          <Stack.Screen name="EditProfile" component={EditProfileScreen} options={{ title: 'Editar perfil' }} />
        </>
      )}
    </Stack.Navigator>
  );
}
