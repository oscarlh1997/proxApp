import React from 'react';
import { Text, View } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import FeedScreen from '../screens/FeedScreen';
import RadarScreen from '../screens/RadarScreen';
import MessagesScreen from '../screens/MessagesScreen';
import ProfileScreen from '../screens/ProfileScreen';
import { useAuthStore } from '../store/useAuthStore';
import { Colors } from '../theme/colors';

const Tab = createBottomTabNavigator();

const tabIcons: Record<string, { icon: string; label: string }> = {
  Feed: { icon: '🏠', label: 'Inicio' },
  Radar: { icon: '📡', label: 'Radar' },
  Mensajes: { icon: '💬', label: 'Mensajes' },
  Perfil: { icon: '👤', label: 'Perfil' },
};

export default function TabsNavigator() {
  const pendingConnections = useAuthStore((s) => s.pendingConnections);

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerTitleAlign: 'center',
        tabBarIcon: ({ focused }) => {
          const info = tabIcons[route.name] || { icon: '📄', label: '' };
          return (
            <View style={{ alignItems: 'center', position: 'relative' }}>
              <Text style={{ fontSize: 22, opacity: focused ? 1 : 0.5 }}>{info.icon}</Text>
              {route.name === 'Mensajes' && pendingConnections > 0 && (
                <View style={{
                  position: 'absolute', top: -4, right: -10,
                  backgroundColor: '#EF4444', borderRadius: 10,
                  minWidth: 18, height: 18, justifyContent: 'center', alignItems: 'center',
                  paddingHorizontal: 4,
                }}>
                  <Text style={{ color: 'white', fontSize: 10, fontWeight: '800' }}>
                    {pendingConnections > 99 ? '99+' : pendingConnections}
                  </Text>
                </View>
              )}
            </View>
          );
        },
        tabBarActiveTintColor: Colors.primary,
        tabBarInactiveTintColor: Colors.subtext,
        tabBarStyle: {
          backgroundColor: Colors.card,
          borderTopColor: Colors.border,
        },
      })}
    >
      <Tab.Screen name="Feed" component={FeedScreen} options={{ title: 'Inicio' }} />
      <Tab.Screen name="Radar" component={RadarScreen} options={{ title: 'Radar' }} />
      <Tab.Screen name="Mensajes" component={MessagesScreen}
        options={{
          title: 'Mensajes',
          tabBarBadge: pendingConnections > 0 ? pendingConnections : undefined,
          tabBarBadgeStyle: { backgroundColor: '#EF4444', fontSize: 10 },
        }}
      />
      <Tab.Screen name="Perfil" component={ProfileScreen} options={{ title: 'Perfil' }} />
    </Tab.Navigator>
  );
}
