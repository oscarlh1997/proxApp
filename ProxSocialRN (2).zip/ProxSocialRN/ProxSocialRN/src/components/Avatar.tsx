import React from 'react';
import { Image, ImageStyle } from 'react-native';

export function avatarUrl(seed: string, size = 64): string {
  return `https://api.dicebear.com/7.x/identicon/png?seed=${encodeURIComponent(seed)}&size=${size}`;
}

export const Avatar: React.FC<{
  seed: string;
  size?: number;
  style?: ImageStyle;
  /** URL de imagen personalizada (tiene prioridad sobre seed) */
  imageUrl?: string | null;
}> = ({ seed, size = 40, style, imageUrl }) => (
  <Image
    source={{ uri: imageUrl || avatarUrl(seed, Math.round(size * 2)) }}
    style={[
      { width: size, height: size, borderRadius: size / 2, backgroundColor: '#E5E7EB' },
      style,
    ]}
  />
);
