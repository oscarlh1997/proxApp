import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { Colors } from '../theme/colors';
import { NearbyUser } from '../types/models';
import { Avatar } from './Avatar';
import { TagChip } from './TagChip';

const STATUS_EMOJI: Record<string, string> = {
  soltero: '💚', soltera: '💚', en_relacion: '❤️', casado: '💍', casada: '💍', es_complicado: '💛',
};

export const NearbyUserCard: React.FC<{
  user: NearbyUser;
  onConnect?: () => void;
  /** Intereses del usuario actual para resaltar coincidencias */
  myInterests?: string[];
}> = ({ user, onConnect, myInterests = [] }) => {
  const tags = user.interests || user.tags || [];
  const statusEmoji = STATUS_EMOJI[user.relationshipStatus || ''] || '';
  const mySet = new Set(myInterests.map(t => t.toLowerCase()));
  const shared = tags.filter(t => mySet.has(t.toLowerCase()));
  const notShared = tags.filter(t => !mySet.has(t.toLowerCase()));

  return (
    <Pressable onPress={onConnect}
      style={{ backgroundColor: Colors.card, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, padding: 12, marginBottom: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Avatar seed={user.avatarSeed} size={44} />
        <View style={{ marginLeft: 10, flex: 1 }}>
          <Text style={{ color: Colors.text, fontWeight: '700' }}>
            {user.displayName} {statusEmoji}
          </Text>
          <Text style={{ color: Colors.subtext }}>
            ~{user.distanceM < 1 ? '<1' : Math.round(user.distanceM)} m
            {user.bio ? ` · ${user.bio.slice(0, 40)}${user.bio.length > 40 ? '…' : ''}` : ''}
          </Text>
        </View>
        <View style={{ backgroundColor: Colors.primary, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999 }}>
          <Text style={{ color: 'white', fontWeight: '700', fontSize: 13 }}>Ver</Text>
        </View>
      </View>

      {/* Shared interests highlighted */}
      {(shared.length > 0 || notShared.length > 0) && (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 }}>
          {shared.slice(0, 4).map((t) => (
            <View key={t} style={{ backgroundColor: '#DBEAFE', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, marginRight: 6, marginBottom: 4, borderWidth: 1, borderColor: Colors.primary }}>
              <Text style={{ color: Colors.primary, fontWeight: '700', fontSize: 12 }}>✨ #{t}</Text>
            </View>
          ))}
          {notShared.slice(0, Math.max(0, 4 - shared.length)).map((t) => <TagChip key={t} label={t} />)}
        </View>
      )}

      {shared.length > 0 && (
        <Text style={{ color: Colors.primary, fontSize: 11, fontWeight: '600', marginTop: 4 }}>
          {shared.length} {shared.length === 1 ? 'interés' : 'intereses'} en común
        </Text>
      )}

      {/* Social links preview */}
      {user.socialLinks && user.socialLinks.length > 0 && (
        <View style={{ flexDirection: 'row', marginTop: 6, gap: 8 }}>
          {user.socialLinks.slice(0, 3).map((l, i) => (
            <View key={i} style={{ backgroundColor: '#F1F5F9', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 }}>
              <Text style={{ color: Colors.subtext, fontSize: 11, textTransform: 'capitalize' }}>{l.platform}</Text>
            </View>
          ))}
        </View>
      )}
    </Pressable>
  );
};
